@Repository
public interface ConductorRepository extends JpaRepository<Conductor, Long> {
}
