@Entity
public class Bus {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String placa;
    private String modelo;

    @ManyToMany(mappedBy = "buses")
    private List<Conductor> conductores = new ArrayList<>();

    // Getters y Setters
}
