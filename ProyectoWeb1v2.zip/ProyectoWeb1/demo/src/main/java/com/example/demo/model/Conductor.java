@Entity
public class Conductor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nombre;
    private String cedula;
    private String telefono;
    private String direccion;

    @ManyToMany
    @JoinTable(
        name = "conductor_bus",
        joinColumns = @JoinColumn(name = "conductor_id"),
        inverseJoinColumns = @JoinColumn(name = "bus_id")
    )
    private List<Bus> buses = new ArrayList<>();

    // Getters y Setters
}
