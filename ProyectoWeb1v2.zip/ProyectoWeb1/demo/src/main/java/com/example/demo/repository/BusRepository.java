@Repository
public interface BusRepository extends JpaRepository<Bus, Long> {
}
